package com.fsd.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;

@Entity
public class Registration {
    public Registration() {
		super();
	}

	public Registration(Long id, int numberOfAdults, int numberOfChildren, User user, Event event, 
			List<FoodOption> foodOptions, Payment payment) {
		super();
		this.id = id;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.user = user;
		this.event = event;
		
		this.payment = payment;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Min(value = 0, message = "Number of children cannot be negative")
    private int numberOfAdults;
    
    @Min(value = 0, message = "Number of children cannot be negative")
    private int numberOfChildren;
    
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    
    @JsonIgnoreProperties({"registrations"})
    @ManyToOne
    @JoinColumn(name = "event_id")
    private Event event;
    @OneToOne(cascade = CascadeType.ALL)
    private Payment payment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNumberOfAdults() {
		return numberOfAdults;
	}

	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}

	public int getNumberOfChildren() {
		return numberOfChildren;
	}

	public void setNumberOfChildren(int numberOfChildren) {
		this.numberOfChildren = numberOfChildren;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}



	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	@Override
	public String toString() {
		return "Registration [id=" + id + ", numberOfAdults=" + numberOfAdults + ", numberOfChildren="
				+ numberOfChildren + ", user=" + user + ", event=" + event  + ", foodOptions="
				 + ", payment=" + payment + "]";
	}

    
}
