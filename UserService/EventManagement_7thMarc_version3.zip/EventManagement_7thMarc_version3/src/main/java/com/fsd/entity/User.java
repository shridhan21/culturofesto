package com.fsd.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name="users")
public class User {
    public User(Long id, String username, String password, String email, String role,
			List<Registration> registrations) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
		this.role = role;
		this.registrations = registrations;
	}


	public User() {
		super();
	}


	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String username;
    private String password;
    private String email;
    private String role;

    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL)
    List<Registration> registrations;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public List<Registration> getRegistrations() {
		return registrations;
	}


	public void setRegistrations(List<Registration> registrations) {
		this.registrations = registrations;
	}
        
}
